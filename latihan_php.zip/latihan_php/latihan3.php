<html>
<head>
<title>Contoh php Hitung Harga</title>
</head>
<body>
<?php
$jumlah_beli=5;
$harga=20000;
$total=$harga*$jumlah_beli;

echo" Jumlah Beli = $jumlah_beli <br>";
echo " Harga Barang = $harga <br> ";
echo " Total Bayar  : $total <br>"



?>

</body>
</html>