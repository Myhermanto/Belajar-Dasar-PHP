<html>
    <head>
        <title> Contoh Tugas 1</title>
    </head>

    <body>
<?php
$judul="<h1>Biodata Saya</h1>";
$nama="Hermanto, M.Kom";
$alamat=" Jl.Dewi Sartika, Cawang  No 77";
$email="hermanto.hmt@bsi.ac.id";
$telpon="081256261611";
$Hobi="Badminton";

echo"$judul <br>";
echo" Nama Saya : $nama <br>";
echo" Alamat    : $alamat <br>";
echo" Email    : $email <br>";
echo" Telpon    : $telpon <br>";
echo" Hoby    : $Hobi <br>";

?>

    </body>
</html>