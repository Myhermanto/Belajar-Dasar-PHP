<html>
<head>
    
<title> Menghitung Luas Lingkarang</title>
</head>
<body>

<?php
$judul1=" Ini Judul Contoh";
define("judul","Hitung Luas Lingkaran");
define("PHI",3.14);

echo judul;
$r=10;

echo" <br> $judul1 <br>";
echo" <br> Jari-jari : $r <br>";
$luas= PHI*$r*$r;

echo" Luas Lingkaran = $luas ";

?>


</body>

</html>