<?php

echo"<h3>Belajar Dasar-Dasar PHP</h3>";
echo" Ini adalah Script PHP Pertama saya <br> ";
echo" Saya Sedang Belajar PHP ";

?>

