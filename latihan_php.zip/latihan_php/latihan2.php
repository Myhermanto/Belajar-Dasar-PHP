<html>
<head>
<title> Contoh Script PHP</title>
</head>
<body>
<?php 

$nim="12345678";
$nama="Hermanto ";
$kelas="12.1A.01";


echo "Nim Saya = $nim <br>";
echo "Nama Saya = $nama <br> ";
echo " Kelas Saya = $kelas <br>";

?>

</body>
</html>